# Change Log
All notable changes to this project will be documented in this file.


## [0.1.0] - 2019-01-17
### Added
- Initial test version.
- Developed in outline.

## [1.0.0] - 2019-01-18
### Added
- First release version.

## [1.0.1] - 2019-01-23
### Added
- Minor update.

## [1.0.2] - 2019-03-25
### Added
- First release version.

## [1.1.0] - 2019-07-04
### Added
- Simplified UI making it easier to choose items.
- Restricts quiz and category selection to course or course category context.

## [1.1.1] - 2019-07-24
### Added
- Show category path to disambiguate development and live categories.