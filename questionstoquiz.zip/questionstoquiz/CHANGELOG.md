# Change Log
All notable changes to this project will be documented in this file.


## [0.1.0] - 2019-01-17
### Added
- Initial test version.
- Developed in outline.

## [1.0.0] - 2019-01-18
### Added
- First release version.

## [1.0.1] - 2019-01-23
### Added
- Minor update.

## [1.0.2] - 2019-03-25
### Added
- First release version.
